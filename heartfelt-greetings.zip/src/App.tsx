import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Heart, 
  Sparkles, 
  Gift, 
  HelpCircle, 
  Edit3, 
  Send, 
  Check,
  X,
  Type
} from 'lucide-react';

// --- Types ---
type Page = 'home' | 'cards' | 'editor' | 'about' | 'faq';
type Tier = 'basic' | 'premium';

interface CardTemplate {
  id: string;
  title: string;
  tier: Tier;
  image: string;
  category: string;
}

// --- Mock Data ---
const TEMPLATES: CardTemplate[] = [
  { id: '1', title: 'Golden Anniversary', tier: 'premium', image: 'https://picsum.photos/seed/anniversary/600/800', category: 'Anniversary' },
  { id: '2', title: 'Simple Birthday', tier: 'basic', image: 'https://picsum.photos/seed/birthday/600/800', category: 'Birthday' },
  { id: '3', title: 'Floral Thank You', tier: 'premium', image: 'https://picsum.photos/seed/thanks/600/800', category: 'Thank You' },
  { id: '4', title: 'Minimalist Hello', tier: 'basic', image: 'https://picsum.photos/seed/hello/600/800', category: 'General' },
  { id: '5', title: 'Celestial Celebration', tier: 'premium', image: 'https://picsum.photos/seed/stars/600/800', category: 'Birthday' },
  { id: '6', title: 'Classic Congratulation', tier: 'basic', image: 'https://picsum.photos/seed/congrats/600/800', category: 'Celebration' },
];

// --- Components ---

const Navbar = ({ currentPage, setPage }: { currentPage: Page, setPage: (p: Page) => void }) => (
  <nav className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-md border-b border-stone-100">
    <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
      <button 
        onClick={() => setPage('home')}
        className="flex items-center gap-2 group cursor-pointer"
      >
        <div className="w-8 h-8 bg-rose-500 rounded-full flex items-center justify-center text-white group-hover:scale-110 transition-transform">
          <Heart size={18} fill="currentColor" />
        </div>
        <span className="serif text-xl font-bold tracking-tight">Heartfelt</span>
      </button>
      
      <div className="flex items-center gap-8">
        <button onClick={() => setPage('home')} className={`text-sm font-medium transition-colors ${currentPage === 'home' ? 'text-rose-600' : 'text-stone-500 hover:text-stone-900'}`}>Home</button>
        <button onClick={() => setPage('about')} className={`text-sm font-medium transition-colors ${currentPage === 'about' ? 'text-rose-600' : 'text-stone-500 hover:text-stone-900'}`}>About</button>
        <button onClick={() => setPage('faq')} className={`text-sm font-medium transition-colors ${currentPage === 'faq' ? 'text-rose-600' : 'text-stone-500 hover:text-stone-900'}`}>How it Works</button>
        <button 
          onClick={() => setPage('cards')}
          className="bg-stone-900 text-white px-5 py-2 rounded-full text-sm font-medium hover:bg-stone-800 transition-all"
        >
          Browse Cards
        </button>
      </div>
    </div>
  </nav>
);

const HomePage = ({ onSelectTier }: { onSelectTier: (t: Tier) => void }) => (
  <div className="pt-32 pb-20 px-6">
    <div className="max-w-4xl mx-auto text-center mb-20">
      <motion.h1 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="serif text-6xl md:text-7xl font-light mb-6 leading-tight"
      >
        Digital greetings, <br />
        <span className="italic">beautifully crafted.</span>
      </motion.h1>
      <motion.p 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="text-stone-500 text-lg max-w-xl mx-auto"
      >
        Send more than just a message. Choose from our curated collection of artistic e-cards and personalize them for your loved ones.
      </motion.p>
    </div>

    <div className="max-w-5xl mx-auto grid md:grid-cols-2 gap-8">
      {/* Basic Tier */}
      <motion.div 
        whileHover={{ y: -10 }}
        className="bg-white p-10 rounded-[2rem] border border-stone-100 shadow-sm flex flex-col items-center text-center"
      >
        <div className="w-16 h-16 bg-stone-50 rounded-2xl flex items-center justify-center mb-6">
          <Gift className="text-stone-400" size={32} />
        </div>
        <h3 className="serif text-3xl mb-2">Basic Collection</h3>
        <div className="text-4xl font-light mb-6">$3<span className="text-lg text-stone-400">/card</span></div>
        <ul className="text-stone-500 space-y-3 mb-10 text-sm">
          <li className="flex items-center gap-2"><Check size={16} className="text-emerald-500" /> Standard Artistic Designs</li>
          <li className="flex items-center gap-2"><Check size={16} className="text-emerald-500" /> Basic Text Customization</li>
          <li className="flex items-center gap-2"><Check size={16} className="text-emerald-500" /> Instant Email Delivery</li>
        </ul>
        <button 
          onClick={() => onSelectTier('basic')}
          className="w-full py-4 rounded-2xl border-2 border-stone-900 font-semibold hover:bg-stone-900 hover:text-white transition-all"
        >
          Choose Basic
        </button>
      </motion.div>

      {/* Premium Tier */}
      <motion.div 
        whileHover={{ y: -10 }}
        className="bg-stone-900 p-10 rounded-[2rem] text-white flex flex-col items-center text-center relative overflow-hidden"
      >
        <div className="absolute top-6 right-6 bg-rose-500 text-[10px] font-bold uppercase tracking-widest px-3 py-1 rounded-full">
          Popular
        </div>
        <div className="w-16 h-16 bg-white/10 rounded-2xl flex items-center justify-center mb-6">
          <Sparkles className="text-rose-400" size={32} />
        </div>
        <h3 className="serif text-3xl mb-2">Premium Collection</h3>
        <div className="text-4xl font-light mb-6">$4<span className="text-lg text-white/40">/card</span></div>
        <ul className="text-white/60 space-y-3 mb-10 text-sm">
          <li className="flex items-center gap-2"><Check size={16} className="text-rose-400" /> Exclusive Premium Designs</li>
          <li className="flex items-center gap-2"><Check size={16} className="text-rose-400" /> Advanced Layout Editor</li>
          <li className="flex items-center gap-2"><Check size={16} className="text-rose-400" /> Animated Transitions</li>
          <li className="flex items-center gap-2"><Check size={16} className="text-rose-400" /> Scheduled Delivery</li>
        </ul>
        <button 
          onClick={() => onSelectTier('premium')}
          className="w-full py-4 rounded-2xl bg-rose-500 font-semibold hover:bg-rose-600 transition-all"
        >
          Go Premium
        </button>
      </motion.div>
    </div>
  </div>
);

const CardsPage = ({ tier, onSelectCard }: { tier: Tier | null, onSelectCard: (c: CardTemplate) => void }) => {
  const filteredTemplates = tier ? TEMPLATES.filter(t => t.tier === tier) : TEMPLATES;

  return (
    <div className="pt-32 pb-20 px-6 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
        <div>
          <h2 className="serif text-5xl mb-4 capitalize">{tier ? `${tier} Collection` : 'All Cards'}</h2>
          <p className="text-stone-500">Select a template to start personalizing your greeting.</p>
        </div>
        <div className="flex gap-2 overflow-x-auto pb-2 md:pb-0">
          {['All', 'Birthday', 'Anniversary', 'Thank You'].map(cat => (
            <button key={cat} className="px-4 py-2 rounded-full text-sm border border-stone-200 hover:border-stone-900 transition-colors whitespace-nowrap">
              {cat}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
        {filteredTemplates.map((card, idx) => (
          <motion.div 
            key={card.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.05 }}
            className="group cursor-pointer"
            onClick={() => onSelectCard(card)}
          >
            <div className="aspect-[3/4] rounded-3xl overflow-hidden mb-4 relative">
              <img 
                src={card.image} 
                alt={card.title} 
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <div className="bg-white text-stone-900 px-6 py-3 rounded-full font-medium flex items-center gap-2">
                  <Edit3 size={18} /> Edit Card
                </div>
              </div>
            </div>
            <h4 className="serif text-xl mb-1">{card.title}</h4>
            <span className="text-xs uppercase tracking-widest text-stone-400 font-bold">{card.category}</span>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

const EditorPage = ({ card, onBack }: { card: CardTemplate, onBack: () => void }) => {
  const [message, setMessage] = useState("Wishing you a day filled with happiness and a year filled with joy. Happy Birthday!");
  const [recipient, setRecipient] = useState("");
  const [fontSize, setFontSize] = useState(24);
  const [color, setColor] = useState("#1c1917");

  return (
    <div className="pt-24 min-h-screen flex flex-col md:flex-row bg-stone-50">
      {/* Sidebar Controls */}
      <div className="w-full md:w-96 bg-white border-r border-stone-200 p-8 overflow-y-auto">
        <button onClick={onBack} className="flex items-center gap-2 text-stone-400 hover:text-stone-900 mb-8 transition-colors">
          <X size={20} /> Cancel Editing
        </button>
        
        <h2 className="serif text-3xl mb-8">Personalize</h2>

        <div className="space-y-8">
          <div>
            <label className="block text-xs font-bold uppercase tracking-widest text-stone-400 mb-3">Recipient Name</label>
            <input 
              type="text" 
              value={recipient}
              onChange={(e) => setRecipient(e.target.value)}
              placeholder="Enter name..."
              className="w-full px-4 py-3 rounded-xl border border-stone-200 focus:outline-none focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500 transition-all"
            />
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-widest text-stone-400 mb-3">Your Message</label>
            <textarea 
              rows={4}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-stone-200 focus:outline-none focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500 transition-all resize-none"
            />
          </div>

          <div className="grid grid-cols-1 gap-6">
            <div>
              <label className="block text-xs font-bold uppercase tracking-widest text-stone-400 mb-3">Font Size</label>
              <div className="flex items-center gap-3">
                <Type size={16} className="text-stone-400" />
                <input 
                  type="range" min="12" max="48" 
                  value={fontSize}
                  onChange={(e) => setFontSize(parseInt(e.target.value))}
                  className="w-full accent-rose-500" 
                />
              </div>
            </div>
            <div>
              <label className="block text-xs font-bold uppercase tracking-widest text-stone-400 mb-3">Text Color</label>
              <div className="flex items-center gap-2">
                {['#1c1917', '#e11d48', '#059669', '#2563eb', '#d97706'].map(c => (
                  <button 
                    key={c}
                    onClick={() => setColor(c)}
                    className={`w-6 h-6 rounded-full border-2 ${color === c ? 'border-stone-900 scale-110' : 'border-transparent'}`}
                    style={{ backgroundColor: c }}
                  />
                ))}
              </div>
            </div>
          </div>

          <button className="w-full py-4 bg-stone-900 text-white rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-stone-800 transition-all shadow-lg shadow-stone-900/10">
            <Send size={18} /> Send Greeting
          </button>
        </div>
      </div>

      {/* Preview Area */}
      <div className="flex-1 p-6 md:p-12 flex items-center justify-center overflow-hidden">
        <motion.div 
          layoutId={`card-${card.id}`}
          className="bg-white shadow-2xl rounded-[2.5rem] overflow-hidden max-w-md w-full aspect-[3/4] flex flex-col relative"
        >
          <div className="h-1/2 overflow-hidden">
            <img 
              src={card.image} 
              alt={card.title} 
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="flex-1 p-6 md:p-10 flex flex-col items-center justify-center text-center">
            {recipient && (
              <motion.h4 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="serif text-xl md:text-2xl mb-4 text-stone-400 italic"
              >
                Dear {recipient},
              </motion.h4>
            )}
            <p 
              className="serif leading-relaxed"
              style={{ fontSize: `${fontSize}px`, color: color }}
            >
              {message}
            </p>
            <div className="mt-8 pt-8 border-t border-stone-100 w-full">
              <span className="serif text-lg italic text-stone-400">With love, Heartfelt</span>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

const AboutPage = () => (
  <div className="pt-32 pb-20 px-6 max-w-4xl mx-auto">
    <h2 className="serif text-6xl mb-12 text-center">Our Story</h2>
    <div className="aspect-video rounded-[3rem] overflow-hidden mb-16">
      <img src="https://picsum.photos/seed/studio/1200/800" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
    </div>
    <div className="prose prose-stone lg:prose-xl mx-auto">
      <p className="serif text-2xl leading-relaxed mb-8">
        Heartfelt was born from a simple observation: in our fast-paced digital world, 
        the art of the personal message was being lost to quick texts and generic emojis.
      </p>
      <p className="text-stone-500 leading-relaxed mb-6">
        We believe that a greeting card is more than just paper or pixels—it's a vessel for emotion, 
        a moment of connection, and a lasting memory. Our mission is to combine the timeless 
        elegance of traditional stationery with the convenience of digital delivery.
      </p>
      <p className="text-stone-500 leading-relaxed">
        Every template in our collection is hand-picked or custom-designed by independent artists, 
        ensuring that your message is wrapped in beauty. Whether it's a milestone birthday, 
        a quiet thank you, or a grand celebration, we're here to help you say it better.
      </p>
    </div>
  </div>
);

const FAQPage = () => {
  const faqs = [
    { q: "How do I send a card?", a: "Simply choose a pricing tier, select a design you love, personalize it with your message, and enter the recipient's email address. We'll handle the rest!" },
    { q: "Can I schedule a card for later?", a: "Yes! Our Premium tier allows you to pick a specific date and time for your card to be delivered, so you never miss a special moment." },
    { q: "What's the difference between Basic and Premium?", a: "Basic cards offer beautiful standard designs and text editing. Premium gives you access to exclusive artist collections, advanced layout tools, and scheduled delivery." },
    { q: "Is it secure?", a: "Absolutely. We use industry-standard encryption to protect your data and ensure your messages are only seen by the intended recipient." }
  ];

  return (
    <div className="pt-32 pb-20 px-6 max-w-3xl mx-auto">
      <h2 className="serif text-6xl mb-12 text-center">How it Works</h2>
      <div className="space-y-6">
        {faqs.map((faq, i) => (
          <div key={i} className="bg-white p-8 rounded-3xl border border-stone-100 shadow-sm">
            <h4 className="serif text-2xl mb-4 flex items-center gap-3">
              <HelpCircle className="text-rose-500" size={24} />
              {faq.q}
            </h4>
            <p className="text-stone-500 leading-relaxed">{faq.a}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

// --- Main App ---

export default function App() {
  const [page, setPage] = useState<Page>('home');
  const [selectedTier, setSelectedTier] = useState<Tier | null>(null);
  const [selectedCard, setSelectedCard] = useState<CardTemplate | null>(null);

  const handleSelectTier = (tier: Tier) => {
    setSelectedTier(tier);
    setPage('cards');
    window.scrollTo(0, 0);
  };

  const handleSelectCard = (card: CardTemplate) => {
    setSelectedCard(card);
    setPage('editor');
    window.scrollTo(0, 0);
  };

  const navigateTo = (p: Page) => {
    setPage(p);
    window.scrollTo(0, 0);
  };

  return (
    <div className="min-h-screen bg-[#fdfcfb]">
      <Navbar currentPage={page} setPage={navigateTo} />
      
      <main>
        <AnimatePresence mode="wait">
          <motion.div
            key={page}
            initial={{ opacity: 0, x: 10 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -10 }}
            transition={{ duration: 0.3 }}
          >
            {page === 'home' && <HomePage onSelectTier={handleSelectTier} />}
            {page === 'cards' && <CardsPage tier={selectedTier} onSelectCard={handleSelectCard} />}
            {page === 'editor' && selectedCard && (
              <EditorPage card={selectedCard} onBack={() => navigateTo('cards')} />
            )}
            {page === 'about' && <AboutPage />}
            {page === 'faq' && <FAQPage />}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Footer */}
      {page !== 'editor' && (
        <footer className="bg-stone-900 text-white py-20 px-6">
          <div className="max-w-7xl mx-auto grid md:grid-cols-4 gap-12">
            <div className="col-span-2">
              <div className="flex items-center gap-2 mb-6">
                <div className="w-8 h-8 bg-rose-500 rounded-full flex items-center justify-center text-white">
                  <Heart size={18} fill="currentColor" />
                </div>
                <span className="serif text-2xl font-bold tracking-tight">Heartfelt</span>
              </div>
              <p className="text-white/40 max-w-sm">
                Elevating digital connections through artistic design and personal touch.
              </p>
            </div>
            <div>
              <h5 className="text-xs font-bold uppercase tracking-widest text-white/20 mb-6">Platform</h5>
              <ul className="space-y-4 text-sm text-white/60">
                <li><button onClick={() => navigateTo('home')} className="hover:text-white transition-colors cursor-pointer">Home</button></li>
                <li><button onClick={() => navigateTo('cards')} className="hover:text-white transition-colors cursor-pointer">Browse Cards</button></li>
                <li><button onClick={() => navigateTo('faq')} className="hover:text-white transition-colors cursor-pointer">How it Works</button></li>
              </ul>
            </div>
            <div>
              <h5 className="text-xs font-bold uppercase tracking-widest text-white/20 mb-6">Company</h5>
              <ul className="space-y-4 text-sm text-white/60">
                <li><button onClick={() => navigateTo('about')} className="hover:text-white transition-colors cursor-pointer">About Us</button></li>
                <li><button className="hover:text-white transition-colors">Contact</button></li>
                <li><button className="hover:text-white transition-colors">Privacy Policy</button></li>
              </ul>
            </div>
          </div>
          <div className="max-w-7xl mx-auto mt-20 pt-8 border-t border-white/5 text-center text-white/20 text-xs">
            © 2024 Heartfelt Greetings. All rights reserved.
          </div>
        </footer>
      )}
    </div>
  );
}
